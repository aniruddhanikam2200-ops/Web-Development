from flask import Flask, request, jsonify
from flask_cors import CORS
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, classification_report
import json
import os

app = Flask(__name__)
CORS(app)

# ─── Generate synthetic student dataset ───────────────────────────────────────
def generate_dataset(n=500):
    np.random.seed(42)
    attendance        = np.random.uniform(30, 100, n)
    study_hours       = np.random.uniform(0, 12, n)
    assignment_completion = np.random.uniform(20, 100, n)
    previous_marks    = np.random.uniform(30, 100, n)
    participation     = np.random.uniform(0, 10, n)
    sleep_hours       = np.random.uniform(4, 10, n)

    # Score formula (weighted)
    score = (
        0.25 * attendance +
        0.30 * study_hours * 8 +
        0.20 * assignment_completion +
        0.20 * previous_marks +
        0.05 * participation * 9
    ) / 100 * 100

    score += np.random.normal(0, 5, n)
    score = np.clip(score, 0, 100)

    def classify(s):
        if s >= 75: return "Excellent"
        elif s >= 55: return "Good"
        elif s >= 35: return "Average"
        else:        return "Poor"

    performance = [classify(s) for s in score]

    df = pd.DataFrame({
        "attendance":              attendance.round(1),
        "study_hours":             study_hours.round(1),
        "assignment_completion":   assignment_completion.round(1),
        "previous_marks":          previous_marks.round(1),
        "participation":           participation.round(1),
        "sleep_hours":             sleep_hours.round(1),
        "score":                   score.round(1),
        "performance":             performance,
    })
    return df

# ─── Train models ─────────────────────────────────────────────────────────────
FEATURES = ["attendance", "study_hours", "assignment_completion",
            "previous_marks", "participation", "sleep_hours"]
LABEL_ORDER = ["Excellent", "Good", "Average", "Poor"]

df_global = generate_dataset(500)
X = df_global[FEATURES]
y = df_global["performance"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled  = scaler.transform(X_test)

models = {
    "Random Forest":   RandomForestClassifier(n_estimators=100, random_state=42),
    "Gradient Boost":  GradientBoostingClassifier(n_estimators=100, random_state=42),
    "Logistic Reg.":   LogisticRegression(max_iter=1000, random_state=42),
}

model_metrics = {}
for name, model in models.items():
    if name == "Logistic Reg.":
        model.fit(X_train_scaled, y_train)
        preds = model.predict(X_test_scaled)
        cv = cross_val_score(model, scaler.transform(X), y, cv=5).mean()
    else:
        model.fit(X_train, y_train)
        preds = model.predict(X_test)
        cv = cross_val_score(model, X, y, cv=5).mean()
    acc = accuracy_score(y_test, preds)
    model_metrics[name] = {"accuracy": round(acc * 100, 2), "cv_score": round(cv * 100, 2)}

primary_model = models["Random Forest"]  # best performer typically

# ─── Routes ───────────────────────────────────────────────────────────────────

@app.route("/api/predict", methods=["POST"])
def predict():
    data = request.json
    try:
        features = pd.DataFrame([{
            "attendance":            float(data["attendance"]),
            "study_hours":           float(data["study_hours"]),
            "assignment_completion": float(data["assignment_completion"]),
            "previous_marks":        float(data["previous_marks"]),
            "participation":         float(data["participation"]),
            "sleep_hours":           float(data["sleep_hours"]),
        }])

        prediction = primary_model.predict(features)[0]
        probabilities = primary_model.predict_proba(features)[0]
        classes = primary_model.classes_

        proba_dict = {cls: round(float(prob) * 100, 1)
                      for cls, prob in zip(classes, probabilities)}

        # Feature importances
        importances = dict(zip(FEATURES, primary_model.feature_importances_))

        # Compute a raw score (weighted)
        raw_score = (
            0.25 * float(data["attendance"]) +
            0.30 * float(data["study_hours"]) * 8 +
            0.20 * float(data["assignment_completion"]) +
            0.20 * float(data["previous_marks"]) +
            0.05 * float(data["participation"]) * 9
        ) / 100 * 100
        raw_score = round(min(max(raw_score, 0), 100), 1)

        # Suggestions
        suggestions = []
        if float(data["attendance"]) < 75:
            suggestions.append("📅 Improve attendance – aim for at least 75%")
        if float(data["study_hours"]) < 4:
            suggestions.append("📚 Increase daily study hours to at least 4h")
        if float(data["assignment_completion"]) < 80:
            suggestions.append("✏️ Complete more assignments – target 80%+")
        if float(data["previous_marks"]) < 60:
            suggestions.append("📈 Review past subjects to strengthen your base")
        if float(data["sleep_hours"]) < 6:
            suggestions.append("😴 Get at least 6–8 hours of sleep for better retention")

        return jsonify({
            "prediction": prediction,
            "probabilities": proba_dict,
            "estimated_score": raw_score,
            "feature_importances": {k: round(v * 100, 1) for k, v in importances.items()},
            "suggestions": suggestions,
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route("/api/model-stats", methods=["GET"])
def model_stats():
    return jsonify({
        "models": model_metrics,
        "dataset_size": len(df_global),
        "features": FEATURES,
        "class_distribution": df_global["performance"].value_counts().to_dict(),
    })


@app.route("/api/dataset-sample", methods=["GET"])
def dataset_sample():
    sample = df_global.sample(10, random_state=1).to_dict(orient="records")
    return jsonify({"sample": sample})


@app.route("/api/analytics", methods=["GET"])
def analytics():
    stats = {}
    for feat in FEATURES:
        stats[feat] = {
            "mean":  round(df_global[feat].mean(), 2),
            "std":   round(df_global[feat].std(), 2),
            "min":   round(df_global[feat].min(), 2),
            "max":   round(df_global[feat].max(), 2),
        }
    correlation = df_global[FEATURES + ["score"]].corr()["score"].drop("score")
    return jsonify({
        "statistics": stats,
        "score_correlation": {k: round(v, 3) for k, v in correlation.items()},
        "performance_counts": df_global["performance"].value_counts().to_dict(),
    })


@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "models_trained": list(models.keys())})


if __name__ == "__main__":
    app.run(debug=True, port=5000)